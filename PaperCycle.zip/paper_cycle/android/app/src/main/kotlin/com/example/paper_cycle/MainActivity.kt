package com.example.paper_cycle

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
